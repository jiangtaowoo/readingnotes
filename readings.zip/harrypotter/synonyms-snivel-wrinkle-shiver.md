tags: #synonym

# 哭
- [[whine]] - 哭啼，包含诉求
- [[snivel]] - 哭啼，包含诉求
- [[sniffle]] - 抽泣，仅仅是行为
- [[snort]] - 哼哼
- [[creak]]
	- v. 发出高分贝的噪声
# 褶皱 萎缩 枯萎
- [[wrinkle]]  同时用作 _[noun]_  _[verb]_
	- n. 褶皱
	- n. 比喻义，小困难、聪明的解决办法
	- v. 褶皱
- [[crinkle]]  同时用作 _[noun]_  _[verb]_
	- v. 褶皱，只是不平，没有变小
- [[shrivel]] 仅用作 _[verb]_
	- v. 萎缩，变小

# movie quickly
- [[shiver]]
	- v. verb.motion 因激动/害怕而颤抖（表达感情倾向）
	- v. verb.body 因寒冷而发抖（纯粹的身体状态），这种情况也做 n.
- [[twitch]]
	- n. 因紧张等产生的无法自控的肌肉颤抖
	- v. **无法自控**的身体颤抖，他的脸在颤抖
- [[quiver]]
	- n. 情绪的震颤
	- n. 箭筒
	- v. 快速的抖动（一般无感情倾向）
	- v. 前后快速抖动
- [[wriggle]] 人或物抖动、蠕动
	- v. 做弯曲的微小运动（如小孩想从大人的怀抱里**挣脱**）