tags: #synonym

参见：[[ACTIONS - COMMUNICATIVE#Vocalize 77]]

# 说
## 带情绪的说
- [[roar]] _[音量 200% 怒吼,咆哮]_
	- [[harrypotter1#^83c889]]
	- [[harrypotter1#^446c33]]
- [[rant]] _[音量 150% 怒吼,咆哮]_
	- [[harrypotter1#^44be0a]]
- [[howl]] _[音量 100% 悲伤的嗥叫]_
	- [[harrypotter1#^3515f1]]
	- [[harrypotter1#^0bcff6]]
- [[growl]] _[音量 20% 低吼, 带情绪, back off]_
	- [[harrypotter1#^ef84f2]]
	- [[harrypotter1#^d56a8d]]
- [[snarl]] _[音量 20% 低吼, 带情绪, back off]_  _[一团乱麻]_
	- [[harrypotter1#^db2d70]]
- [[grumble]] _[音量 15% 抱怨, 发牢骚]_  _[无情绪的低沉轰鸣]_
	- [[harrypotter1#^158d58]]
- [[groan]] _[音量 12% 痛苦的呻吟, 不满的哼哼]_  _[无情绪的嘎吱声]_
	- [[harrypotter1#^8d918b]]
- [[moan]] _[音量 12% 痛苦的呻吟, 不满的哼哼]_
	- [[harrypotter1#^efdebd]]
---
以下情绪较弱
- [[squeal]] _[音量 120% 因激动或紧张尖叫]_
	- [[harrypotter1#^559b09]]
- [[grunt]] _[音量 12% 对自己或他人嘀咕, 不满]_
	- [[harrypotter1#^43ae8e]]
	- [[harrypotter1#^71a9fe]]
- [[mutter]] _[音量 12% 对自己或他人嘀咕, 不满]_
	- [[harrypotter1#^4636a4]]
- [[murmur]] _[音量 10% 低语, 远距离的声音, 咕哝或抱怨]_
	- [[harrypotter1#^d1aa1b]]

## 无情绪或情绪较弱的说
- [[shriek]] _[音量 125% 尖叫]_
	- [[harrypotter1#^672305]]
- [[yell]] _[音量 120% 叫喊, 叫嚷]_
	- [[harrypotter1#^a0eb3b]]
	- [[harrypotter1#^009420]]
- [[rumble]] _[音量 20% 持续而低沉的轰鸣(如雷声)]_
	- [[harrypotter1#^6f2e07]]
- [[mumble]] _[音量 5% 呓语, 喃喃自语]_
	- [[harrypotter1#^fbe2df]]

# 其他关联词
- [[swallow]] _[吞咽]_
- [[ramble]] _[漫步, 闲扯(无意义的聊天, go on and on)]_