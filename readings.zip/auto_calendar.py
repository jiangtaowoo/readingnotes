# -*- coding: utf-8 -*-
import os
import shutil
import inspect
from datetime import datetime
from sys import argv
import argparse

"""
记忆周期分别为
- 当天新记忆一组单词
- 复习
  - 14, 7, 3, 1 天前的单词
"""

"""
输入: 01 MOC - HarryPotter.md
内容类似:
        tags: #MOC 

        # Daily Vocabulary
        - [[words-2021-07-30]]
        - [[words-2021-07-31]]
        - [[words-2021-08-01]]
        - [[words-2021-08-02]]
        - [[words-2021-08-03]]
        - [[words-2021-08-05]]
        - [[words-2021-08-06]]
        - [[words-2021-08-07]]
        - [[words-2021-08-08]]
        - [[words-2021-08-09]]
        - [[words-2021-08-10]]
        - [[words-2021-08-11]]

        # Phrases
输出:
   1. 新增一行, 当天的单词计划表
   2. 将要背诵的内容以todo标记 
"""

cur_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))

#依据记忆规律, 返回list对应的位置是否应该在今日做复习(True)
def memory_regulation(memlist):
    strides = [1,3,7,14,35,87,217] #当天应该复习前1,3,7,14天的内容
    return list(reversed([True if i+1 in strides else False for i in range(len(memlist))]))

def gen_calendar_markdown(filepath):
    #判断某一行是否为单词记忆list
    def _is_word_list(line):
        if '[[words-' in line:
            return True
        else:
            return False
    #将todo转化为普通列表 "- [ ] xxx" -> "- xxx"
    def _todo_2_normal(line):
        flags = {"- [ ] ": "- ",
                "- [x] ": "- "}
        for k,v in flags.items():
            if k in line:
                return line.replace(k, v)
        return line
    #将普通列表转换为todo "- xxx" -> "- [ ] xxx"
    def _normal_2_todo(line):
        if "- " in line:
            return line.replace("- ", "- [ ] ")
        return line
    lines = []
    wordlines = []
    if os.path.exists(filepath):
        #备份文件
        shutil.copy(filepath, 
               filepath+"_"+datetime.now().strftime('%Y-%m-%d')+".bak")
        #操作
        with open(filepath) as infile:
            for line in infile:
                lines.append(line)
        #step1. 先把所有todo删除
        lines = list( map(lambda x:_todo_2_normal(x) if _is_word_list(x) else x, 
                        lines) )
        #step2. 找出单词背诵清单, 每个item是 (行号,内容) 元组
        wordlines = list(filter( lambda x:_is_word_list(x[1]), 
                                 zip(range(len(lines)),lines)))
        #step3. 按照记忆规律,将待背诵单词转换为todo
        mem_flags = memory_regulation(wordlines)
        newwordlines = list( map(lambda x: (x[1][0],_normal_2_todo(x[1][1])) 
                                           if x[0] else x[1],
                              zip(mem_flags, wordlines)) )
        #step4. 替换原文,生成新内容
        for x in newwordlines:
            lines[x[0]] = x[1]
        #step5. 新增一行今天的todo
        todotoday = "- [ ] [[words-" + datetime.today().strftime("%Y-%m-%d") + "]]\n"
        lines.insert(newwordlines[-1][0]+1, todotoday)
        #step5. 保存文件
        with open(filepath, "w") as outf:
            for line in lines:
                outf.write(line)
"""
def main(filename):
    if os.path.isabs(filename):
        filepath = filename
    else:
        filepath = os.path.abspath(filename)
    gen_calendar_markdown(filepath)
"""

# 提取content中的内链（[[内容]]）, 生成列表
def extract_inner_link(content):
    words = []
    pos = 0
    while True:
        pos = content.find("[[", pos)
        if pos < 0:
            break
        posend = content.find("]]", pos)
        if posend > 0:
            theword = content[pos+2:posend]
            words.append(theword)
            pos = posend + 2
        else:
            break
    return words

def main():
    parser = argparse.ArgumentParser(
        description='Generate todo for vocabulary list according to memorized rule.')
    # 可选参数: 从 数据库 或者 wordlistfile 中读取数据, 如果没有提供, 则从默认的vocabulary.db 读取数据
    parser.add_argument("-f", "--markdownfile", type=str, 
                        help="the markdown file path where the vocabulary list stored.")
    parser.add_argument("-e", "--extractinnerlinkfile", type=str, 
                        help="the markdown file path where we want to extract inner link.")
    args = parser.parse_args()
    if args.markdownfile:
        filepath = args.markdownfile
        gen_calendar_markdown(filepath)
    if args.extractinnerlinkfile:
        if os.path.exists(args.extractinnerlinkfile):
            words = extract_inner_link(open(args.extractinnerlinkfile).read())
            if words:
                print("\n".join(["## [[{0}]]".format(w.lower()) for w in words]))


if __name__=="__main__":
    main()
